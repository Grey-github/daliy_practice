//main1.c
#include <stdio.h>

int main()
{
	printf("hello, this main1\n");

	return 0;
}

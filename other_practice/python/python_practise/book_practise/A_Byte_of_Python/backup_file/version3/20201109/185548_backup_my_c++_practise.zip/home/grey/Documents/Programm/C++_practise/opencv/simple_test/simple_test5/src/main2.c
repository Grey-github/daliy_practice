//main2.c
#include <stdio.h>

int main()
{
	printf("hello, this main2\n");

	return 0;
}

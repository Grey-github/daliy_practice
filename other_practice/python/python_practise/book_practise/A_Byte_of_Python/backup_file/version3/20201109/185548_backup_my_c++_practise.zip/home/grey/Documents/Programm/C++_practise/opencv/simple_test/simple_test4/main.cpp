#include <iostream>
using namespace std;

int main()
{ 
	auto data = 100;
	cout << "data: " << data << endl;
	return 0;
}

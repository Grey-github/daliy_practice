#include <iostream>
using namespace std;
//�����ڲ��ͣ�https://blog.csdn.net/Acheld/article/details/54578179?locationNum=2&fps=1 
int main()
{
	long long a;
	cin>>a;
	cout<<a<<endl;
	printf("%lld",a);
}

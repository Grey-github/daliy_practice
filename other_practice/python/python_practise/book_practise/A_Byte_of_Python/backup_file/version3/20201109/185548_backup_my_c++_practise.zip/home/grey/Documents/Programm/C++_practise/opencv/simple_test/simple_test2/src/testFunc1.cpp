//testFunc1.cpp
#include <iostream>
#include "testFunc1.h"

using namespace std;

void func1(int data)
{
	cout<<"data is "<<data<<endl;
}

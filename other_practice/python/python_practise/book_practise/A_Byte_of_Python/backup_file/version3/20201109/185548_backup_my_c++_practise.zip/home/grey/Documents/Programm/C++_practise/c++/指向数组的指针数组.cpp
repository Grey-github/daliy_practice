# include <iostream>
using namespace std;

int main()
{
	double(*p[3])[2];
		return 0;
	
} 

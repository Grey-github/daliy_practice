#include <iostream>
using namespace std;
int main()
{
	char ch = 2;
	if (ch == 2)
	{
		cout<<"Equal"<<endl;
	}
}

#include <iostream>

using namespace std;

int main()
{
	int a[2][2];
	cout<<a<<endl;
	cout<<*(a+3)<<endl;
} 

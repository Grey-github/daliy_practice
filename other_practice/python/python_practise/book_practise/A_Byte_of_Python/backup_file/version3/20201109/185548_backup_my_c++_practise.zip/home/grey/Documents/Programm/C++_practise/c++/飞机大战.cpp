# include <iostream>
# include <windows.h>
using namespace std;

int main()
{
	
	int a[2];
	cin>>a[10];
	return 0;
} 

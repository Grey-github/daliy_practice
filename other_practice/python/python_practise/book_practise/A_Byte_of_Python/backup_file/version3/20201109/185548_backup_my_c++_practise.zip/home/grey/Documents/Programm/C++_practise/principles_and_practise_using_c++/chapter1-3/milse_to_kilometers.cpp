#include <iostream>
using namespace std;

int main()
{
	double miles;
	cout<<"Please input a number represent miles:"<<endl;
	cin>>miles;
	cout<<miles<<" miles"<<" = "<<1.609*miles<<" kilometers"<<endl;
	return 0;
}

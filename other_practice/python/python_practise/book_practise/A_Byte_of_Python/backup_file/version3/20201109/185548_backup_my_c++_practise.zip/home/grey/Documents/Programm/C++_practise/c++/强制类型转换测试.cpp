#include <iostream>

using namespace std;

int main()
{
	double a = 12.8;
	cout<<(int)a<<endl;
}

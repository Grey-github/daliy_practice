# include <iostream>
using namespace std;
int main(){
	cout<<"operating\tsysteam\n";
	cout<<'\101'<<'\t'<<'A'<<"\b\b"<<'B'<<'\012';
	return 0;
} 

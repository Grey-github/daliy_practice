#include <iostream>
#include "testFunc.h"

using namespace std;

int main()
{
	func(100);

	return 0;
}

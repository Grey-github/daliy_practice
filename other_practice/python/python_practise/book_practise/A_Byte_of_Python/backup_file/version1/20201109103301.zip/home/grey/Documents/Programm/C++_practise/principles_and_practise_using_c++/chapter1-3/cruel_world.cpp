#include <iostream>
using namespace std;

int main()
{
	string s = "Goodbye, cruel world!";
	cout<<s<<'\n';
}

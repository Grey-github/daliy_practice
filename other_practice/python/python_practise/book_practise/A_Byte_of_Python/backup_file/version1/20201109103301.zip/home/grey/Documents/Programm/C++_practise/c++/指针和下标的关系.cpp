# include <stdio.h>

int main()
{
	int a[5];
	
	printf("%d %d\n",a[0],a[5]);
	
	return 0;
}

# include <stdio.h>
struct node
{
	int data;
	struct node * p;
};
int main()
{
	struct node i;
	scanf("%d",&i.data);
	return 0;
	
} 
//

#include <iostream>
#include <string>
using namespace std;
 
int main()
{
	string operation;//��������Ĳ�����������Ӧ������
	double value1;
	double value2;
	
	cout<<"Please input the operation(+  - * /) and two values in turn."<<endl;
	cout<<"For example, + 100 3.14"<<endl;
	cin>>operation>>value1>>value2;
	
	if (operation == "+")//�ӷ� 
	{
		cout<<value1<<operation<<value2
			<<" = " <<value1 + value2<<endl;
	}
	else if (operation == "-")//���� 
	{
		cout<<value1<<operation<<value2
			<<" = " <<value1 - value2<<endl;
	}
	else if (operation == "*")//�˷� 
	{
		cout<<value1<<operation<<value2
			<<" = " <<value1*value2<<endl;
	}
	else if (operation == "/")//���� 
	{
		cout<<value1<<operation<<value2
			<<" = " <<value1/value2<<endl;
	}
	else 
	{
		cout<<"This is not the operation I know"<<endl;
	}
	
	return 0;
}

//testFunc.cpp
#include <iostream>
using namespace std;

void func(int data)
{
	cout<<"data is "<<data<<endl;
}

#include <iostream>

using namespace std;

int main()
{
	int n;
	cin>>n;
	int a[n];
	const int b = 5;
	int c[b];
} 

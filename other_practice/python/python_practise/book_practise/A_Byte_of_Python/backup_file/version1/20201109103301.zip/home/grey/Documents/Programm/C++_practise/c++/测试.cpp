# include <iostream>
using namespace std;
int main()
{
	int a, b;
	cout<<a=b;
 } 

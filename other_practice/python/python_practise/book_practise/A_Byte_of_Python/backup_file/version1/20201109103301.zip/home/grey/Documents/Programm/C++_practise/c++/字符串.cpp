#include <iostream> 
#include <string>
using namespace std;

int main()
{
	string s = "Bet";
	s = s + "ty";
	cout<<s<<endl;
	if (s > "C")
	{
		cout<<"true"<<endl;
	}
	return 0;
} 

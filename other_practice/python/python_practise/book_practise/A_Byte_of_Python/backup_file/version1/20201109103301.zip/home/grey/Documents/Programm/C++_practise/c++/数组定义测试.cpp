#include <iostream>

using namespace std;

int main()
{
	int n;
	cin>>n;
	int a[n] = {0};
	cout<<a[0]<<endl;
	const int b = 9;
	int c[b];
} 

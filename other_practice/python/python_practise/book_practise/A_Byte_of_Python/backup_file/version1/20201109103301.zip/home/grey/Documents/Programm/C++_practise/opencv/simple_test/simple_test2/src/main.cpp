#include <iostream>

#include "testFunc.h"
#include "testFunc1.h"
using namespace std;

int main()
{
	func(100);
	func1(200);

	return 0;
}

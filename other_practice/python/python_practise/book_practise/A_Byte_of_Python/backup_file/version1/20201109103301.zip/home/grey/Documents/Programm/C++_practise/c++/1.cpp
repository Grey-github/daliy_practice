# include <iostream>
using namespace std;

int main()
{
	cout<<'A'<<'A'<<"\b\b"<<"I";
	
	return 0;
}

#include<iostream>
using namespace std;
int main ()
{
	cout<<"short int"<<sizeof(short int)<<endl;
	cout<<"int"<<sizeof(int)<<endl;
	cout<<"long int"<<sizeof(long int)<<endl;
	cout<<"char"<<sizeof(char)<<endl;
	cout<<"bool"<<sizeof(bool)<<endl;
	cout<<"float"<<sizeof(float)<<endl;
	cout<<"double"<<sizeof(double)<<endl;
	return 0;
}
	

      

